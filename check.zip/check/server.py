import socket
import datetime
import sqlite3



last_date = datetime.datetime.now().strftime('%Y-%m-%d %H:%M')

HOST = "127.0.0.1"
PORT = 5060
DB = "data.sqlite"

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.bind((HOST,PORT))
    s.listen()
    conn, addr = s.accept()



    while True:

        data = conn.recv(1024)
        message = data.decode()
        Station_id,Alarm1,Alarm2 = message.split()
        # Alarm1 = message.split()
        # Alarm2 = message.split()
        print("Station_id:{}, Alarm1:{}, Alarm2:{}".format(Station_id, Alarm1, Alarm2))
        if not data:
            break

    with conn:
        print(f"Connected by {addr}")
        with sqlite3.connect(DB) as info:
            info.execute('''
                 create table if not exists station_status (
                 Station_id INTEGER,
                 last_date TEXT,
                 Alarm1 INTEGER,
                 Alarm2 INTEGER,
                 PRIMARY KEY (station_id));

                 ''')
            with sqlite3.connect(DB) as conn:
                conn.execute('''
                    INSERT OR REPLACE INTO station_status
                    VALUES (?, ?, ?, ?);
                     ''', (Station_id, last_date, Alarm1, Alarm2))
                print("data has been updated successfully")

    # while True:
    #
    #     data = conn.recv(1024)
    #     message = data.decode()
    #     print(message)
    #     Station_id = message.split()[0]
    #     Alarm1 = message.split()[1]
    #     Alarm2 = message.split()[2]
    #     print("Station_id:{}, Alarm1:{}, Alarm2:{}".format(Station_id, Alarm1, Alarm2))
    #     if not data:
    #         break
