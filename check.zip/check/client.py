import socket
import sys
import time

HOST = "127.0.0.1"
FILE= "status.txt"
PORT = 5060  # The port used by the server

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.connect((HOST,PORT))

    with open(FILE, 'r') as f:
        lines = f.readlines()
        line = [lines.rstrip() for lines in lines]
        #print(line)
        message = (' '.join(str(i) for i in line))
        is_numeric = message.replace(" ","")
        if is_numeric.isnumeric():
            print(message)
            #len(message)
            data = message.encode()
            print(len(data))
            s.sendto(data,(HOST,PORT))



        else:
            print("Wrong data")
            is_running = False